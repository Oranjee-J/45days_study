# 模型
EMBED_MODEL = "mxbai-embed-large"
LLM_MODEL = "deepseek-r1:7b"

# 文本切分参数
CHUNK_SIZE = 500
CHUNK_OVERLAP = 100

# 检索参数
TOP_K = 3

# 路径
RAW_DATA_PATH = "data/raw/paper.pdf"
DB_PATH = "models/chroma_db"