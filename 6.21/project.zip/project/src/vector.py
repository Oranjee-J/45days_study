from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaEmbeddings
from langchain_chroma import Chroma
import config
import os


def build_vector_db(
        file_path,
        chunk_size=config.CHUNK_SIZE,
        chunk_overlap=config.CHUNK_OVERLAP,
        db_path=config.DB_PATH
):

    loader = TextLoader(
        file_path,
        encoding="utf-8"
    )

    docs = loader.load()

    print(f"读取到 {len(docs)} 个文档")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap
    )

    chunks = splitter.split_documents(docs)

    print(f"生成 {len(chunks)} 个文本块")

    embeddings = OllamaEmbeddings(
        model=config.EMBED_MODEL
    )

    os.makedirs("models", exist_ok=True)


    vector_db = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=db_path
    )

    print("向量库建立完成")

    return vector_db