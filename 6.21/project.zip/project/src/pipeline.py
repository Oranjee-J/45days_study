from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings, OllamaLLM
import config

def load_models():

    embeddings = OllamaEmbeddings(
        model=config.EMBED_MODEL
    )

    vector_db = Chroma(
        persist_directory="models/chroma_db",
        embedding_function=embeddings
    )

    llm = OllamaLLM(
        model=config.LLM_MODEL
    )

    return vector_db, llm


def ask_question(question, vector_db, llm):

    docs = vector_db.similarity_search(
        question,
        k=config.TOP_K
    )

    context = "\n\n".join(
        [doc.page_content for doc in docs]
    )

    prompt = f"""
Answer the question only based on the following context.

If the answer is not in the context, say:
"I don't know."

Context:
{context}

Question:
{question}

Answer:
"""

    # 调用大模型
    answer = llm.invoke(prompt)

    return answer