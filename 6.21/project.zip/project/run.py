from src.clean import clean_pdf
from src.vector import build_vector_db
from src.pipeline import load_models, ask_question
import src.config as config
from src.utils import set_seed

set_seed(42)
# 清洗文档

clean_file = clean_pdf(
    config.RAW_DATA_PATH
)

# 建立向量库
vector_db = build_vector_db(
    clean_file
)

# 加载模型
vector_db, llm = load_models()

while True:

    question = input("请输入问题(输入exit退出)：")

    if question.lower() == "exit":
        break

    answer = ask_question(
        question,
        vector_db,
        llm
    )

    print("\n===== 回答 =====")
    print(answer)